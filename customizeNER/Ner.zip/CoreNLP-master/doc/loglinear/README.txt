For an explanation of how everything fits together, see ARCH.txt

For a quick runnable object, go run edu.stanford.nlp.loglinear.CoNLLBenchmark in core's test package.

For a tutorial, see QUICKSTART.txt

For a brief overview of testing for this package (which was quite thorough), see TESTING.txt

Look at OPTIMIZATION.txt for an overview of what exists, what's been done, and what we know about further optimizations.